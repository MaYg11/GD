import cv2
import numpy as np

# 读取图像并获取图像尺寸
img = cv2.imread('example.jpg')
height, width = img.shape[:2]

# 定义锐化卷积核
kernel = np.array([[-1,-1,-1],
                   [-1, 9,-1],
                   [-1,-1,-1]])

# 应用锐化卷积核
sharp_img = cv2.filter2D(img, -1, kernel)

# 显示原图和锐化后的图像
cv2.namedWindow('Original Image', cv2.WINDOW_NORMAL)
cv2.imshow('Original Image', img)
cv2.namedWindow('Sharpened Image', cv2.WINDOW_NORMAL)
cv2.imshow('Sharpened Image', sharp_img)

# 调整窗口大小为图像的尺寸
cv2.resizeWindow('Original Image', width, height)
cv2.resizeWindow('Sharpened Image', width, height)

cv2.waitKey(0)
cv2.destroyAllWindows()
#Invoke-WebRequest -Uri http://host.robots.ox.ac.uk/pascal/VOC/voc2007/VOCdevkit_08-Jun-2007.tar -OutFile ./data