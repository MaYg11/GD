import os
import random
import shutil

data_dir = "D:/Python_Lesson/PycharmProjects/ultralytics-main/datasets/car/JPEGImages"
label_dir = "D:/Python_Lesson/PycharmProjects/ultralytics-main/datasets/car/origin_labels"

train_dir = "datasets/car/images/train"
val_dir = "datasets/car/images/val"
test_dir = "datasets/car/images/test"

train_labels_dir = "datasets/car/labels/train"
val_labels_dir = "datasets/car/labels/val"
test_labels_dir = "datasets/car/labels/test"

os.makedirs(train_dir, exist_ok=True)
os.makedirs(val_dir, exist_ok=True)
os.makedirs(test_dir, exist_ok=True)
os.makedirs(train_labels_dir, exist_ok=True)
os.makedirs(val_labels_dir, exist_ok=True)
os.makedirs(test_labels_dir, exist_ok=True)

images = os.listdir(data_dir)

random.shuffle(images)

train_ratio = 0.6
val_ratio = 0.2
test_ratio = 0.2

num_images = len(images)
num_train = int(num_images * train_ratio)
num_val = int(num_images * val_ratio)

train_images = images[:num_train]
val_images = images[num_train:num_train+num_val]
test_images = images[num_train+num_val:]

def copy_files(images, src_dir, dest_dir, label_dir, dest_label_dir):
    for img in images:
        img_path = os.path.join(src_dir, img)
        shutil.copy(img_path, os.path.join(dest_dir, img))

        img_name, _ = os.path.splitext(img)
        label_file = img_name + '.txt'
        shutil.copy(os.path.join(label_dir, label_file), os.path.join(dest_label_dir, label_file))

copy_files(train_images, data_dir, train_dir, label_dir, train_labels_dir)
copy_files(val_images, data_dir, val_dir, label_dir, val_labels_dir)
copy_files(test_images, data_dir, test_dir, label_dir, test_labels_dir)

print("数据集划分完成！")

